import random
import time

import pygame

pygame.init()

SCREEN = pygame.display.set_mode((1000, 600))

#

# ludu board
board_img = pygame.image.load("25board.png")
board_img_X = 150
board_img_Y = 50

#hard code

# snake image
snake_img = pygame.image.load("Snake1.png")
snake_img_X = 250+10
snake_img_Y = 250+25

#snake2 image
redSnake_img = pygame.image.load("redSnake.png")
redSnake_img_X = 450+10
redSnake_img_Y = 150+25

#Danger check
X_Start=snake_img_X-10
Y_Start=snake_img_Y-25

#Danger Red Snake
X_redSnake_Start=redSnake_img_X-10
Y_redSnake_Start=redSnake_img_Y-25

#ladder image
ladder_image=pygame.image.load("ladder2.png")
ladder_image_X=475
ladder_image_Y=375

#moi otha check
X_LadderEnd=ladder_image_X-25
Y_LadderEnd=ladder_image_Y-25+200

# coin image
coin_img = pygame.image.load("coin.png")
coin_img_X = 150 + 30
coin_img_Y = 50 + 430

# player initial score
player_score = 1

# load dice images
diceImg = []
diceImg.append(pygame.image.load('dice1p2.png'))
diceImg.append(pygame.image.load('dice2p2.png'))
diceImg.append(pygame.image.load('dice3p2.png'))
diceImg.append(pygame.image.load('dice4p2.png'))
diceImg.append(pygame.image.load('dice5p2.png'))
diceImg.append(pygame.image.load('dice6p2.png'))


Final_Coin_Y=coin_img_Y


# draw board
def draw_board(x, y):
    SCREEN.blit(board_img, (x, y))


# draw snake
def draw_snake(x, y,rX,rY):
    SCREEN.blit(snake_img, (x, y))
    SCREEN.blit(redSnake_img, (rX, rY))

def draw_ladder(x,y):
    SCREEN.blit(ladder_image,(x,y))


# draw dice
def draw_dice():
    #print("dice = ", player_score)
    SCREEN.blit(diceImg[player_score - 1], (800, 150))


def draw_coin(x, y):
    SCREEN.blit(coin_img, (x, y))

def coin_Stable():
    global Final_Coin_X
    Final_Coin_X = coin_img_X
    global Final_Coin_Y
    Final_Coin_Y= coin_img_Y



clock = pygame.time.Clock()
time_dice_turned = 0
left_to_right = 1
right_to_left=1
coin_moving = False
dice_rolling = False
player_position = player_score
eating=False
redEating=False
coin_stable=1
uthing=False


running = True

while running:
    SCREEN.fill((195, 115, 42))
    draw_board(board_img_X, board_img_Y)
    draw_snake(snake_img_X, snake_img_Y,redSnake_img_X,redSnake_img_Y)
    draw_ladder(ladder_image_X,ladder_image_Y)
    if player_position==1:
        draw_coin(coin_img_X, coin_img_Y)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if not dice_rolling:
                    dice_rolling = True

    if dice_rolling:
        player_score = random.randint(1, 6)
        # player_score=2
        # draw_dice()
        time_dice_turned += 1
        # time.sleep(.5)
        if time_dice_turned > 2:
            dice_rolling = False
            coin_moving = True
            time_dice_turned = 0
            destination = player_score + player_position
       # print("Score", player_score)
       # print("time dice turned", time_dice_turned)

    draw_dice()



    while(coin_moving):

        if (player_position < destination and destination<=25):
           # print("left to right", left_to_right)

            if player_position % 5 == 0:
                coin_img_Y -= 100
                left_to_right *= -1
            else:
                coin_img_X += left_to_right * 100
            print(coin_img_X,coin_img_Y)
            player_position += 1

            if destination == player_position:
              coin_moving = False


    draw_coin(coin_img_X, coin_img_Y)
    time.sleep(.3)
    coin_Stable()


    #shap amk khacce
    if(X_Start<Final_Coin_X and Final_Coin_X<X_Start+100):
        if(Y_Start<Final_Coin_Y and Final_Coin_Y<Y_Start+100):
            print("shap amk khacce")
            eating=True
           # if (Y_Start-100< coin_img_Y and coin_img_Y< Y_Start):
            while (eating==True):
                if player_position % 5 == 1:
                    coin_img_Y += 100
                    right_to_left *= -1
                else:
                    coin_img_X -= right_to_left * 100
                player_position -= 1
                print(player_position)

                if (Y_Start +200 >coin_img_Y and coin_img_Y > Y_Start+100 and X_Start<coin_img_X and coin_img_X<X_Start+100):
                    print("end")
                    eating=False
                    left_to_right*=-1
                    coin_Stable()

    #redSnake amk khacche
    if (X_redSnake_Start < Final_Coin_X and Final_Coin_X < X_redSnake_Start + 100):
        if (Y_redSnake_Start < Final_Coin_Y and Final_Coin_Y < Y_redSnake_Start + 100):
            print("red shap amk khacce")
            redEating = True
            # if (Y_Start-100< coin_img_Y and coin_img_Y< Y_Start):
            while (redEating == True):
                if player_position % 5 == 1:
                    coin_img_Y += 100
                    right_to_left *= -1
                else:
                    coin_img_X -= right_to_left * 100
                player_position -= 1
                print(player_position)

                if (Y_redSnake_Start + 200 > coin_img_Y and coin_img_Y > Y_redSnake_Start + 100 and X_redSnake_Start < coin_img_X and coin_img_X < X_redSnake_Start + 100):
                    print("end")
                    redEating = False
                    left_to_right *= -1
                    coin_Stable()


#ami moi khacchi

    if (X_LadderEnd < Final_Coin_X and Final_Coin_X < X_LadderEnd + 100):
        if (Y_LadderEnd-100 < Final_Coin_Y and Final_Coin_Y < Y_LadderEnd):
            print("moi e uthc")
            uthing= True
            # if (Y_Start-100< coin_img_Y and coin_img_Y< Y_Start):
            while (uthing == True):
                print("uthc")
                if player_position % 5 == 0:
                    coin_img_Y -= 100
                    left_to_right *= -1
                else:
                    coin_img_X += left_to_right * 100
                player_position += 1
                print(player_position)


                if (Y_LadderEnd -100 > coin_img_Y and coin_img_Y > Y_LadderEnd -200 and X_LadderEnd < coin_img_X and coin_img_X < X_LadderEnd+ 100):
                    print("uthing end")
                    uthing = False
                    coin_Stable()


    #print("coin moving , dice rolling", coin_moving, dice_rolling)
    clock.tick(60)
    time.sleep(.05)
    pygame.display.update()
