import pygame
from diceMove import diceMove

pygame.init()

screen=pygame.display.set_mode((1250,650))
player_score=1

diceImg=[]
diceImg.append(pygame.image.load('dice1p2.png'))
diceImg.append(pygame.image.load('dice2p2.png'))
diceImg.append(pygame.image.load('dice3p2.png'))
diceImg.append(pygame.image.load('dice4p2.png'))
diceImg.append(pygame.image.load('dice5p2.png'))
diceImg.append(pygame.image.load('dice6p2.png'))


def BoardGeneration():
    board=pygame.image.load('25board.png')
    screen.blit(board,(200,50))

def dice():
    screen.blit(diceImg[player_score-1],(800,150))


running = True
while running:

    # RGB = Red, Green, Blue
    screen.fill((100, 0, 0))

    BoardGeneration()

    for event in pygame.event.get():
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_SPACE:
                player_score=diceMove()
                dice()
        if event.type == pygame.QUIT:
            running = False

    dice()

    pygame.display.update()
