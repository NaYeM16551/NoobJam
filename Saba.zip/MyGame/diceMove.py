import random
def diceMove():
    move = random.randrange(1, 7, 1)
    return move
    
